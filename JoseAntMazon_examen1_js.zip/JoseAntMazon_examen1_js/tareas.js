const btnAdd=document.getElementById("btnAdd");
const btnBorrarTodas=document.getElementById("btnBorrarTodas");
let lista_tareas=[];
let ul=document.getElementById("listaTareas");    
btnAdd.addEventListener("click",function () {
    let error=document.getElementById("error");
    error.textContent="";
    let txtTarea=document.getElementById("txtTarea").value.trim();
    document.getElementById("txtTarea").value="";//para borrar el input en html;
    if (txtTarea==="") {
        error.textContent="Error:la tarea no podria estar vacia";
        return;
    }
    lista_tareas.push(txtTarea);
    let contador=document.getElementById("contador");
    contador.textContent=lista_tareas.length;
    ul.innerHTML="";
    for (let i = 0; i < lista_tareas.length; i++) {
        let li=document.createElement("li");
        li.textContent=lista_tareas[i];
        ul.appendChild(li);
        li.addEventListener("click",function () {
            li.classList.toggle("completada");
        })
    }
});
btnBorrarTodas.addEventListener("click",function () {
    //   for (let i = 0; i < lista_tareas.length; i++) {
    //         lista_tareas.pop();
    //   }
    lista_tareas=[];
    let contador=document.getElementById("contador");
    contador.textContent=lista_tareas.length;
    ul.innerHTML="";
    })


    