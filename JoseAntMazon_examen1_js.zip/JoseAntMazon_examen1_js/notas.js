function calcularMedia(lista_notas) {
    let media=0;
    let total=0;
    for (let i = 0; i < lista_notas.length; i++) {
            total+=lista_notas[i];
    }
    media=(total/lista_notas.length);
    return media.toFixed(2);
}
function contarAprobados(lista_notas) {
    let cantidaAprobados=0;
    for (let i = 0; i < lista_notas.length; i++) {
        if (lista_notas[i]>4) {
            ++cantidaAprobados;
        }
    }
    return cantidaAprobados;
}
function maximaNota(lista_notas) {
    maxima=lista_notas[0];
    for (let i = 0; i < lista_notas.length; i++) {
        if (maxima<lista_notas[i]) {
            maxima=lista_notas[i];
        }
    }
    return maxima;
}
function minimaNota(lista_notas) {
    minima=lista_notas[0];
    for (let i = 0; i < lista_notas.length; i++) {
        if (minima>lista_notas[i]) {
            minima=lista_notas[i];
        }
    }
    return minima;
}
let lista_notas=[];
let numero_user="";
let mostrar=document.getElementById("salidaNotas");

do {
    numero_user=Number(prompt("Escribe tus notas:[0-10]-1 para salir"));
    if (numero_user<0 || numero_user>10) {
        continue;        
    }
    else{
        numero=Number(numero_user);
        lista_notas.push(numero);
    }
} while (numero_user!==-1);
if (numero_user===-1) {
    let media=calcularMedia(lista_notas);
    let aprobados=contarAprobados(lista_notas);
    let maxima_nota=maximaNota(lista_notas);
    let minima_nota=minimaNota(lista_notas);
    //MEDIA
    let media_mostrada=document.createElement("p");
    media_mostrada.textContent=`La media es:${media}`;
    console.log("Media de notas"+media_mostrada);
    //APROBADOS
    let aprobados_mostrada=document.createElement("p");
    aprobados_mostrada.textContent=`La cantidad de aprobados:${aprobados}`;
    console.log(aprobados_mostrada);
    //MAXIMA
    let maxima_mostrada=document.createElement("p");
    maxima_mostrada.textContent=`La maxima nota es:${maxima_nota}`;
    console.log("Maxima nota:"+maxima_nota);
    //MINIMA
    let minima_mostrada=document.createElement("p");
    minima_mostrada.textContent=`La minima nota es:${minima_nota}`;
    console.log("Minima Nota:"+minima_nota);
    //LE METO LOS DATOS EN MOSTRAR
    mostrar.appendChild(media_mostrada);
    mostrar.appendChild(aprobados_mostrada);
    mostrar.appendChild(maxima_mostrada);
    mostrar.appendChild(minima_mostrada);    
}
console.log("nunca entra en el if")



