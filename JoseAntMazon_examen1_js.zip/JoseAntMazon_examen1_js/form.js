const { createElement } = require("react");

let formulario=document.getElementById("formContacto");
let todoCorrectoValido=false;
let todoCorrecto=document.getElementById("ok");
formulario.addEventListener("submit",function (event) {
    event.preventDefault();
    let todoOK=true;
    let nombre=document.getElementById("nombre").value.trim();
    let errorNombre=document.getElementById("errNombre");
    let email=document.getElementById("email").value;
    let errorEmail=document.getElementById("errEmail");
    let mensaje=document.getElementById("mensaje").value.trim();
    let errorMensaje=document.getElementById("errMensaje");
    if (nombre==="") {
        errorNombre.textContent="Error:el nombre es obligatorio";
        todoOK=false;
    }
    if (mensaje.length<10) {
        errorMensaje.textContent="Error el mensaje tiene que tener minimo 10 caracteres";
        todoOK=false;
    }
    const regexEmail="/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\[A-Za-z]{2,}$/";
    const esValido=regexEmail.test(email.trim())
    if (!esValido) {
        errorEmail.textContent="Error en el formato del email";
        todoOK=false;
    }
    if (todoOK) {
        let p=document.createElement("p");
        p.textContent="Formulario enviado correctamente";
        formulario.appendChild(p);
        p.style.color="green";
        todoCorrectoValido=true;
    }
})
if (todoCorrectoValido) {
    todoCorrecto.textContent="Formulario enviado correctamente";
}